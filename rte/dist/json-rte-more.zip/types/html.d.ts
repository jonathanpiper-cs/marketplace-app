declare global {
    interface Window {
        rte: any;
    }
}
export declare const html: (RTE: any) => any;
