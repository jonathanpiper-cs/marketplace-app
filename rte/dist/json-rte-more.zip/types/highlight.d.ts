export declare const highlight: (RTE: any) => any;
