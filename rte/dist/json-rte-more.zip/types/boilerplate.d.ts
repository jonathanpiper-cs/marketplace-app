declare global {
    interface Window {
        rte: any;
    }
}
export declare const insertBoilerplate: (RTE: any) => any;
