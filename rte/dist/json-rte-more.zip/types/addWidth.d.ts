declare global {
    interface Window {
        rte: any;
    }
}
export declare const addWidth: (RTE: any) => any;
