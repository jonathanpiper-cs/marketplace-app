declare global {
    interface Window {
        rte: any;
    }
}
export declare const setFontWeight: (RTE: any) => any;
