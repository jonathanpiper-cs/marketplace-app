declare global {
    interface Window {
        rte: any;
    }
}
export declare const getEntryValue: (RTE: any) => any;
