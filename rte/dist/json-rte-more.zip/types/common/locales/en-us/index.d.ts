declare const localeTexts: {
    RTE: {
        title: string;
        description: string;
        body: string;
        button: {
            learnMore: string;
        };
    };
};
export default localeTexts;
