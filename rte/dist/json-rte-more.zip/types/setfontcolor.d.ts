declare global {
    interface Window {
        rte: any;
    }
}
export declare const setFontColor: (RTE: any) => any;
