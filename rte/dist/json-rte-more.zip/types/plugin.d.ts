declare const _default: Promise<{
    SetFontWeight: any;
    AddWidth: any;
    InsertBoilerplate: any;
    SetFontColor: any;
    SetFontSize: any;
    InsertUniCH: any;
    Nofollow: any;
} | undefined>;
export default _default;
