declare global {
    interface Window {
        rte: any;
    }
}
export declare const nofollow: (RTE: any) => any;
