export declare const createRateRTE: (RTE: any) => any;
