declare global {
    interface Window {
        rte: any;
    }
}
export declare const removeHeadingMargin: (RTE: any) => any;
